#include <stdio.h>

int main()
{
   int x = 'A' + 'd' + 'a';
   printf("%d\n", x);
}
