#include <stdio.h>
int main()
{
    printf("%d\n", 'A' + 'd' + 'a');
    return 0;
}
