#include <bits/stdc++.h>
using namespace std;
int main()
{
    cout << 'A' + 'd' + 'a' << endl;
    return 0;
}
