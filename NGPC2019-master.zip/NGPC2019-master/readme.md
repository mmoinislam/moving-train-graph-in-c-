![](https://uploads.toph.co/arena-images/1570007152539447659-5792023559445812070-88b757133689ac02b9bafb12e73a7497.jpg)

# NGPC 2019

For time and memory constraints, look for the zip from toph
