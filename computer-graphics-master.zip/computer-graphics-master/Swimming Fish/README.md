# Fish is swimming

## Steps

1. Draw fish
2. change the x value and y value 
3. clear screen
4. GOTO 1